'use strict';
var MimeMapper = {
    _typeToExtensionMap: {
        'image/jpeg': 'jpg',
        'image/png': 'png',
        'image/gif': 'gif',
        'image/bmp': 'bmp',
        'audio/mpeg': 'mp3',
        'audio/mp4': 'm4a',
        'audio/ogg': 'ogg',
        'audio/webm': 'webm',
        'audio/3gpp': '3gp',
        'audio/amr': 'amr',
        'audio/x-wav': 'wav',
        'video/mp4': 'mp4',
        'video/mpeg': 'mpg',
        'video/ogg': 'ogg',
        'video/webm': 'webm',
        'video/3gpp': '3gp',
        'video/3gpp2': '3g2',
        'application/vcard': 'vcf',
        'text/vcard': 'vcf',
        'text/x-vcard': 'vcf',
        'application/zip': 'zip',
        'text/html': 'html',
        'text/plain': 'txt',
        'application/x-gerda-bundle': 'gab',
        'application/x-bin-image': 'bin',
        'application/x-gb-image': 'gb',
        'application/x-gbc-image': 'gbc',
        'application/x-nes-image': 'nes',
        'application/x-chip8-image': 'ch8'
    },
    _extensionToTypeMap: {
        'jpg': 'image/jpeg',
        'jpeg': 'image/jpeg',
        'jpe': 'image/jpeg',
        'png': 'image/png',
        'gif': 'image/gif',
        'bmp': 'image/bmp',
        'mp3': 'audio/mpeg',
        'm4a': 'audio/mp4',
        'm4b': 'audio/mp4',
        'm4p': 'audio/mp4',
        'm4r': 'audio/mp4',
        'aac': 'audio/aac',
        'opus': 'audio/ogg',
        'amr': 'audio/amr',
        'wav': 'audio/x-wav',
        'mid': 'audio/x-midi',
        'mp4': 'video/mp4',
        'mpeg': 'video/mpeg',
        'mpg': 'video/mpeg',
        'ogv': 'video/ogg',
        'ogx': 'video/ogg',
        'webm': 'video/webm',
        '3gp': 'video/3gpp',
        '3g2': 'video/3gpp2',
        'ogg': 'video/ogg',
        'txt': 'text/plain',
        'html': 'text/html',
        'apk': 'application/vnd.android.package-archive',
        'zip': 'application/zip',
        'vcf': 'text/vcard',
        'gab': 'application/x-gerda-bundle',
        'bin': 'application/x-bin-image',
        'gb': 'application/x-gb-image',
        'gbc': 'application/x-gbc-image',
        'nes': 'application/x-nes-image',
        'ch8': 'application/x-chip8-image'
    },
    _parseExtension: function(filename) {
        var array = filename.split('.');
        return array.length > 1 ? array.pop() : '';
    },
    isSupportedType: function(mimetype) {
        return (mimetype in this._typeToExtensionMap);
    },
    isSupportedExtension: function(extension) {
        return (extension in this._extensionToTypeMap);
    },
    isFilenameMatchesType: function(filename, mimetype) {
        var extension = this._parseExtension(filename);
        var guessedType = this.guessTypeFromExtension(extension);
        return (guessedType == mimetype);
    },
    guessExtensionFromType: function(mimetype) {
        return this._typeToExtensionMap[mimetype];
    },
    guessTypeFromExtension: function(extension) {
        return this._extensionToTypeMap[extension];
    },
    guessTypeFromFileProperties: function(filename, mimetype) {
        var extension = this._parseExtension(filename);
        var type = this.isSupportedType(mimetype) ? mimetype : this.guessTypeFromExtension(extension);
        return type || '';
    },
    ensureFilenameMatchesType: function(filename, mimetype) {
        if (!this.isFilenameMatchesType(filename, mimetype)) {
            var guessedExt = this.guessExtensionFromType(mimetype);
            if (guessedExt) {
                filename += '.' + guessedExt;
            }
        }
        return filename;
    }
};
